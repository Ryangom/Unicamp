prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- ORACLE Application Express (APEX) export file
--
-- You should run the script connected to SQL*Plus as the Oracle user
-- APEX_210200 or as the owner (parsing schema) of the application.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_api.import_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_default_workspace_id=>4083689119968203350
);
end;
/
prompt  WORKSPACE 4083689119968203350
--
-- Workspace, User Group, User, and Team Development Export:
--   Date and Time:   06:49 Monday October 25, 2021
--   Exported By:     1001071@DAFFODIL.AC
--   Export Type:     Workspace Export
--   Version:         21.2.0-18
--   Instance ID:     63113759365424
--
-- Import:
--   Using Instance Administration / Manage Workspaces
--   or
--   Using SQL*Plus as the Oracle user APEX_210200
 
begin
    wwv_flow_api.set_security_group_id(p_security_group_id=>4083689119968203350);
end;
/
----------------
-- W O R K S P A C E
-- Creating a workspace will not create database schemas or objects.
-- This API creates only the meta data for this APEX workspace
prompt  Creating workspace DDD_RYANGOMES...
begin
wwv_flow_fnd_user_api.create_company (
  p_id => 4083936416194206859
 ,p_provisioning_company_id => 4083689119968203350
 ,p_short_name => 'DDD_RYANGOMES'
 ,p_display_name => 'DDD_RYANGOMES'
 ,p_first_schema_provisioned => 'WKSP_DDDRYANGOMES'
 ,p_company_schemas => 'WKSP_DDDRYANGOMES'
 ,p_account_status => 'ASSIGNED'
 ,p_allow_plsql_editing => 'Y'
 ,p_allow_app_building_yn => 'Y'
 ,p_allow_packaged_app_ins_yn => 'Y'
 ,p_allow_sql_workshop_yn => 'Y'
 ,p_allow_websheet_dev_yn => 'Y'
 ,p_allow_team_development_yn => 'Y'
 ,p_allow_to_be_purged_yn => 'Y'
 ,p_allow_restful_services_yn => 'Y'
 ,p_source_identifier => 'DDD_RYAN'
 ,p_webservice_logging_yn => 'Y'
 ,p_path_prefix => 'DDD_RYANGOMES'
 ,p_files_version => 1
 ,p_env_banner_yn => 'N'
 ,p_env_banner_pos => 'LEFT'
);
end;
/
----------------
-- G R O U P S
--
prompt  Creating Groups...
begin
wwv_flow_fnd_user_api.create_user_group (
  p_id => 111224556075029,
  p_GROUP_NAME => 'OAuth2 Client Developer',
  p_SECURITY_GROUP_ID => 10,
  p_GROUP_DESC => 'Users authorized to register OAuth2 Client Applications');
end;
/
begin
wwv_flow_fnd_user_api.create_user_group (
  p_id => 111140893075029,
  p_GROUP_NAME => 'RESTful Services',
  p_SECURITY_GROUP_ID => 10,
  p_GROUP_DESC => 'Users authorized to use RESTful Services with this workspace');
end;
/
begin
wwv_flow_fnd_user_api.create_user_group (
  p_id => 111073851075029,
  p_GROUP_NAME => 'SQL Developer',
  p_SECURITY_GROUP_ID => 10,
  p_GROUP_DESC => 'Users authorized to use SQL Developer with this workspace');
end;
/
prompt  Creating group grants...
----------------
-- U S E R S
-- User repository for use with APEX cookie-based authentication.
--
prompt  Creating Users...
begin
wwv_flow_fnd_user_api.create_fnd_user (
  p_user_id                      => '4083689048114203350',
  p_user_name                    => '1001071@DAFFODIL.AC',
  p_first_name                   => 'Ryan',
  p_last_name                    => 'Gomes',
  p_description                  => '',
  p_email_address                => '1001071@daffodil.ac',
  p_web_password                 => '6635BCB5C0343B6341BFE7C2BA2E3471759C2712E49BDDD9942F18772DF4B874A261068ADECA2D3B129A8D07BEA0BCF0D31481D2BAD33A4ACAB2942B85FEA572',
  p_web_password_format          => '5;5;10000',
  p_group_ids                    => '',
  p_developer_privs              => 'ADMIN:CREATE:DATA_LOADER:EDIT:HELP:MONITOR:SQL',
  p_default_schema               => 'WKSP_DDDRYANGOMES',
  p_account_locked               => 'N',
  p_account_expiry               => to_date('202110201350','YYYYMMDDHH24MI'),
  p_failed_access_attempts       => 0,
  p_change_password_on_first_use => 'Y',
  p_first_password_use_occurred  => 'Y',
  p_allow_app_building_yn        => 'Y',
  p_allow_sql_workshop_yn        => 'Y',
  p_allow_websheet_dev_yn        => 'Y',
  p_allow_team_development_yn    => 'Y',
  p_allow_access_to_schemas      => '');
end;
/
----------------
--App Builder Preferences
--
----------------
--Click Count Logs
--
----------------
--mail
--
----------------
--mail log
--
----------------
--app models
--
----------------
--password history
--
begin
  wwv_flow_api.create_password_history (
    p_id => 4084602190990248469,
    p_user_id => 4083689048114203350,
    p_password => '6635BCB5C0343B6341BFE7C2BA2E3471759C2712E49BDDD9942F18772DF4B874A261068ADECA2D3B129A8D07BEA0BCF0D31481D2BAD33A4ACAB2942B85FEA572');
end;
/
begin
  wwv_flow_api.create_password_history (
    p_id => 4083936627151206869,
    p_user_id => 4083689048114203350,
    p_password => 'ACC8564713DA5652AC23B5D7364ACEF1C30B8DE09E5A178382597F03C7209E9E9AD8C369C333FB02ABD0E1B1924CFFF269C558A58C9B0847BE1AEEE6B8DFFE7F');
end;
/
----------------
--preferences
--
begin
  wwv_flow_api.create_preferences$ (
    p_id => 4121611226105483668,
    p_user_id => '1001071@DAFFODIL.AC',
    p_preference_name => 'F4500_1157684150404338202_SPLITTER_STATE',
    p_attribute_value => '200:false',
    p_tenant_id => '');
end;
/
begin
  wwv_flow_api.create_preferences$ (
    p_id => 4151095870461917157,
    p_user_id => '1001071@DAFFODIL.AC',
    p_preference_name => 'F4500_1157686386582338224_SPLITTER_STATE',
    p_attribute_value => '345:false',
    p_tenant_id => '');
end;
/
begin
  wwv_flow_api.create_preferences$ (
    p_id => 4119468684457507212,
    p_user_id => '1001071@DAFFODIL.AC',
    p_preference_name => 'FSP4500_P2102_R5737432600960966_SORT',
    p_attribute_value => 'sort_2_asc',
    p_tenant_id => '');
end;
/
begin
  wwv_flow_api.create_preferences$ (
    p_id => 4120089389382518501,
    p_user_id => '1001071@DAFFODIL.AC',
    p_preference_name => 'FSP4500_P2155_R15607221124933219_SORT',
    p_attribute_value => 'sort_3_asc',
    p_tenant_id => '');
end;
/
begin
  wwv_flow_api.create_preferences$ (
    p_id => 4086264964477216616,
    p_user_id => '1001071@DAFFODIL.AC',
    p_preference_name => 'FSP_IR_4500_P1004_W467833818073240350',
    p_attribute_value => '467836414517307027____',
    p_tenant_id => '');
end;
/
begin
  wwv_flow_api.create_preferences$ (
    p_id => 4501203073628263894,
    p_user_id => '1001071@DAFFODIL.AC',
    p_preference_name => 'FSP_IR_4500_P1220_W467846302875971481',
    p_attribute_value => '467848523688971977____',
    p_tenant_id => '');
end;
/
----------------
--query builder
--
----------------
--sql scripts
--
----------------
--sql commands
--
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4119162679466503330
 ,p_command => 
'create table customer ('||wwv_flow.LF||
'    customer_id                    number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint customer_id_pk primary key,'||wwv_flow.LF||
'    first_name                     varchar2(50 char),'||wwv_flow.LF||
'    last_name                      varchar2(50 char),'||wwv_flow.LF||
'    email_address                  varchar2(50 char),'||wwv_flow.LF||
'    contact_number                 number,'||wwv_flow.LF||
'    date_of_b'||
'irth                  date'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201433','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4141121636188771883
 ,p_command => 
'truncate table "CUSTOMER"'||wwv_flow.LF||
'/'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201517','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4148561241995872693
 ,p_command => 
'create table suppliers ('||wwv_flow.LF||
'    suppliers_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint suppliers_id_pk primary key,'||wwv_flow.LF||
'    suppliers_name                 varchar2(100 char),'||wwv_flow.LF||
'    address                        varchar2(250 char),'||wwv_flow.LF||
'    contact_number                 number,'||wwv_flow.LF||
'    city                           varchar2(100 char)'||
','||wwv_flow.LF||
'    country                        varchar2(150 char)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201534','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4148565025423873917
 ,p_command => 
'create table showrooms ('||wwv_flow.LF||
'    showrooms_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint showrooms_id_pk primary key,'||wwv_flow.LF||
'    showroom_name                  varchar2(100 char),'||wwv_flow.LF||
'    address                        varchar2(250 char),'||wwv_flow.LF||
'    contact_number                 number,'||wwv_flow.LF||
'    states                         varchar2(100 char)'||
''||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201534','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4148565904310874462
 ,p_command => 
'create table staff_type ('||wwv_flow.LF||
'    staff_type_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint staff_type_id_pk primary key,'||wwv_flow.LF||
'    staff_type_name                varchar2(100 char)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201534','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4148632670371830846
 ,p_command => 
'create table model ('||wwv_flow.LF||
'    model_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint model_id_pk primary key,'||wwv_flow.LF||
'    model_title                    varchar2(50 char),'||wwv_flow.LF||
'    model_year                     varchar2(50 char)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create table suppliers ('||wwv_flow.LF||
'    suppliers_id                             number generated by default on null '||
'as identity '||wwv_flow.LF||
'                                   constraint suppliers_id_pk primary key,'||wwv_flow.LF||
'    suppliers_name                 varchar2(100 char),'||wwv_flow.LF||
'    address                        varchar2(250 char),'||wwv_flow.LF||
'    contact_number                 number,'||wwv_flow.LF||
'    city                           varchar2(100 char),'||wwv_flow.LF||
'    country                        varchar2(150 char)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create table manufacture_info ('||wwv_flow.LF||
'    manufactu'||
're_info_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint manufacture_info_id_pk primary key,'||wwv_flow.LF||
'    manufacture_name               varchar2(255 char),'||wwv_flow.LF||
'    manufacturing_date             date'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create table showrooms ('||wwv_flow.LF||
'    showrooms_id                             number generated by default on null as identity '||wwv_flow.LF||
'           '||
'                        constraint showrooms_id_pk primary key,'||wwv_flow.LF||
'    showroom_name                  varchar2(100 char),'||wwv_flow.LF||
'    address                        varchar2(250 char),'||wwv_flow.LF||
'    contact_number                 number,'||wwv_flow.LF||
'    states                         varchar2(100 char)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create table staff_type ('||wwv_flow.LF||
'    staff_type_id                             number generated by default on null as identity '||wwv_flow.LF||
'   '||
'                                constraint staff_type_id_pk primary key,'||wwv_flow.LF||
'    staff_type_name                varchar2(100 char)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create table departments ('||wwv_flow.LF||
'    departments_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint departments_id_pk primary key,'||wwv_flow.LF||
'    department_name                varchar2(100 char)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create ta'||
'ble vehicle_type ('||wwv_flow.LF||
'    vehicle_type_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint vehicle_type_id_pk primary key,'||wwv_flow.LF||
'    vehicle_type_name              varchar2(100 char)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201534','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4148642295072833148
 ,p_command => 
'create table model ('||wwv_flow.LF||
'    model_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint model_id_pk primary key,'||wwv_flow.LF||
'    model_title                    varchar2(50 char),'||wwv_flow.LF||
'    model_year                     varchar2(50 char)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201534','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4148648280263834272
 ,p_command => 
'create table manufacture_info ('||wwv_flow.LF||
'    manufacture_info_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint manufacture_info_id_pk primary key,'||wwv_flow.LF||
'    manufacture_name               varchar2(255 char),'||wwv_flow.LF||
'    manufacturing_date             date'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201534','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4148658816807836007
 ,p_command => 
'create table departments ('||wwv_flow.LF||
'    departments_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint departments_id_pk primary key,'||wwv_flow.LF||
'    department_name                varchar2(100 char)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201535','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4148670201866836504
 ,p_command => 
'create table vehicle_type ('||wwv_flow.LF||
'    vehicle_type_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint vehicle_type_id_pk primary key,'||wwv_flow.LF||
'    vehicle_type_name              varchar2(100 char)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201535','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4153016485363921936
 ,p_command => 
'create table Order_type ('||wwv_flow.LF||
'    Order_type_id                number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint Order_type_id_pk primary key,'||wwv_flow.LF||
'    Order_type_name              varchar2(100 char)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201549','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4154392792390021253
 ,p_command => 
'create table staff ('||wwv_flow.LF||
'    Staff_id                       number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint staff_id_pk primary key,'||wwv_flow.LF||
'    first_name                     varchar2(100 char),'||wwv_flow.LF||
'    last_name                      varchar2(100 char),'||wwv_flow.LF||
'    email_address                  varchar2(100 char),'||wwv_flow.LF||
'    contact_number                 number,'||wwv_flow.LF||
'    date_of_birt'||
'h                  date,'||wwv_flow.LF||
'    Staff_type_id                  number,'||wwv_flow.LF||
'    Department_id                  number,'||wwv_flow.LF||
'    Showroom_id                    number,'||wwv_flow.LF||
''||wwv_flow.LF||
'    CONSTRAINT fk_Staff_type_id'||wwv_flow.LF||
'    FOREIGN KEY (Staff_type_id)'||wwv_flow.LF||
'    REFERENCES staff_type (staff_type_id),'||wwv_flow.LF||
''||wwv_flow.LF||
'    CONSTRAINT fk_Department_id'||wwv_flow.LF||
'    FOREIGN KEY (Department_id)'||wwv_flow.LF||
'    REFERENCES departments (departments_id),'||wwv_flow.LF||
''||wwv_flow.LF||
'    CONSTRAINT fk_Showroom_'||
'id '||wwv_flow.LF||
'    FOREIGN KEY (Showroom_id)'||wwv_flow.LF||
'    REFERENCES showrooms (showrooms_id)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201559','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4156369715224079697
 ,p_command => 
'create table vehicle_maintenance_record ('||wwv_flow.LF||
'    id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint vehicle_maintenanc_id_pk primary key,'||wwv_flow.LF||
'    service_date                   date,'||wwv_flow.LF||
'    condition_descr                varchar2(4000 char),'||wwv_flow.LF||
'    staff_id                       number,'||wwv_flow.LF||
''||wwv_flow.LF||
'    CONSTRAINT fk_Staff_id'||wwv_flow.LF||
'    FOREIGN KEY (staff'||
'_id)'||wwv_flow.LF||
'    REFERENCES staff (Staff_id)'||wwv_flow.LF||
''||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110201609','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4371478178983378391
 ,p_command => 
'create table vehicle ('||wwv_flow.LF||
'    id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint vehicle_id_pk primary key,'||wwv_flow.LF||
'    vehicale_name                  varchar2(255 char),'||wwv_flow.LF||
'    color                          varchar2(50 char),'||wwv_flow.LF||
'    price                          float(7),'||wwv_flow.LF||
'    vehicle_type_id                number,'||wwv_flow.LF||
'    maintenance_id     '||
'            number,'||wwv_flow.LF||
'    model_id                       number,'||wwv_flow.LF||
'    supplier_id                    number,'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    CONSTRAINT FK_vehicle_type_id FOREIGN KEY (vehicle_type_id) REFERENCES VEHICLE_TYPE(VEHICLE_TYPE_ID),'||wwv_flow.LF||
'    CONSTRAINT FK_maintenance_id FOREIGN KEY (maintenance_id) REFERENCES VEHICLE_MAINTENANCE_RECORD(ID),'||wwv_flow.LF||
'    CONSTRAINT FK_model_id FOREIGN KEY (model_id) REFERENCES MODEL(MODEL_ID),'||wwv_flow.LF||
'   '||
' CONSTRAINT FK_supplier_id FOREIGN KEY (supplier_id) REFERENCES SUPPLIERS (SUPPLIERS_ID));'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110210658','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4371847544761388433
 ,p_command => 
'create table vehicle ('||wwv_flow.LF||
'    id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint vehicle_id_pk primary key,'||wwv_flow.LF||
'    vehicle_name                  varchar2(255 char),'||wwv_flow.LF||
'    color                          varchar2(50 char),'||wwv_flow.LF||
'    price                          float(7),'||wwv_flow.LF||
'    vehicle_type_id                number,'||wwv_flow.LF||
'    maintenance_id      '||
'           number,'||wwv_flow.LF||
'    model_id                       number,'||wwv_flow.LF||
'    supplier_id                    number,'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    CONSTRAINT FK_vehicle_type_id FOREIGN KEY (vehicle_type_id) REFERENCES VEHICLE_TYPE(VEHICLE_TYPE_ID),'||wwv_flow.LF||
'    CONSTRAINT FK_maintenance_id FOREIGN KEY (maintenance_id) REFERENCES VEHICLE_MAINTENANCE_RECORD(ID),'||wwv_flow.LF||
'    CONSTRAINT FK_model_id FOREIGN KEY (model_id) REFERENCES MODEL(MODEL_ID),'||wwv_flow.LF||
'    '||
'CONSTRAINT FK_supplier_id FOREIGN KEY (supplier_id) REFERENCES SUPPLIERS (SUPPLIERS_ID));'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110210700','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4372067995179430330
 ,p_command => 
'create table vehicle ('||wwv_flow.LF||
'    vehicle_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint vehicle_id_pk primary key,'||wwv_flow.LF||
'    vehicle_name                  varchar2(255 char),'||wwv_flow.LF||
'    color                          varchar2(50 char),'||wwv_flow.LF||
'    price                          float(7),'||wwv_flow.LF||
'    vehicle_type_id                number,'||wwv_flow.LF||
'    maintenance_'||
'id                 number,'||wwv_flow.LF||
'    model_id                       number,'||wwv_flow.LF||
'    supplier_id                    number,'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    CONSTRAINT FK_vehicle_type_id FOREIGN KEY (vehicle_type_id) REFERENCES VEHICLE_TYPE(VEHICLE_TYPE_ID),'||wwv_flow.LF||
'    CONSTRAINT FK_maintenance_id FOREIGN KEY (maintenance_id) REFERENCES VEHICLE_MAINTENANCE_RECORD(ID),'||wwv_flow.LF||
'    CONSTRAINT FK_model_id FOREIGN KEY (model_id) REFERENCES MODEL(MODEL_I'||
'D),'||wwv_flow.LF||
'    CONSTRAINT FK_supplier_id FOREIGN KEY (supplier_id) REFERENCES SUPPLIERS (SUPPLIERS_ID));'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110210700','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4372568595697440348
 ,p_command => 
'create table vehicle ('||wwv_flow.LF||
'    vehicle_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint vehicle_id_pk primary key,'||wwv_flow.LF||
'    vehicle_name                  varchar2(255 char),'||wwv_flow.LF||
'    color                          varchar2(50 char),'||wwv_flow.LF||
'    price                          float(7),'||wwv_flow.LF||
'    vehicle_type_id                number,'||wwv_flow.LF||
'    maintenance_'||
'id                 number,'||wwv_flow.LF||
'    model_id                       number,'||wwv_flow.LF||
'    supplier_id                    number,'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    CONSTRAINT FK_vehicle_type_id FOREIGN KEY (vehicle_type_id) REFERENCES VEHICLE_TYPE(VEHICLE_TYPE_ID),'||wwv_flow.LF||
'    CONSTRAINT FK_maintenance_id FOREIGN KEY (maintenance_id) REFERENCES VEHICLE_MAINTENANCE_RECORD(ID),'||wwv_flow.LF||
'    CONSTRAINT FK_model_id FOREIGN KEY (model_id) REFERENCES MODEL(MODEL_I'||
'D),'||wwv_flow.LF||
'    CONSTRAINT FK_supplier_id FOREIGN KEY (supplier_id) REFERENCES SUPPLIERS (SUPPLIERS_ID))'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110210702','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4372603728698441931
 ,p_command => 
'create table vehicle ('||wwv_flow.LF||
'    vehicle_id                             number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint vehicle_id_pk primary key,'||wwv_flow.LF||
'    vehicle_name                  varchar2(255 char),'||wwv_flow.LF||
'    color                          varchar2(50 char),'||wwv_flow.LF||
'    price                          float(7),'||wwv_flow.LF||
'    vehicle_type_id                number,'||wwv_flow.LF||
'    maintenance_'||
'id                 number,'||wwv_flow.LF||
'    model_id                       number,'||wwv_flow.LF||
'    supplier_id                    number,'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    CONSTRAINT FK_vehicle_type_id FOREIGN KEY (vehicle_type_id) REFERENCES VEHICLE_TYPE(VEHICLE_TYPE_ID),'||wwv_flow.LF||
'    CONSTRAINT FK_maintenance_id FOREIGN KEY (maintenance_id) REFERENCES VEHICLE_MAINTENANCE_RECORD(ID),'||wwv_flow.LF||
'    CONSTRAINT FK_model_id FOREIGN KEY (model_id) REFERENCES MODEL(MODEL_I'||
'D),'||wwv_flow.LF||
'    CONSTRAINT FK_supplier_id FOREIGN KEY (supplier_id) REFERENCES SUPPLIERS (SUPPLIERS_ID))'||wwv_flow.LF||
''||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110210702','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4375971202746522471
 ,p_command => 
'create table order ('||wwv_flow.LF||
'    Order_id                       number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint the_order_id_pk primary key,'||wwv_flow.LF||
'    order_date                     date,'||wwv_flow.LF||
'    customer_id                    number,'||wwv_flow.LF||
'    vehicle_id                     number,'||wwv_flow.LF||
'    Order_type_id                  number,'||wwv_flow.LF||
''||wwv_flow.LF||
'    CONSTRAINT FK_customer_id FOREIGN KEY (custom'||
'er_id) REFERENCES CUSTOMER(CUSTOMER_ID),'||wwv_flow.LF||
'    CONSTRAINT FK_vehicle_id FOREIGN KEY (vehicle_id) REFERENCES VEHICLE(VEHICLE_ID),'||wwv_flow.LF||
'    CONSTRAINT FK_Order_type_id  FOREIGN KEY (Order_type_id) REFERENCES ORDER_TYPE(ORDER_TYPE_ID)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110210716','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4376031497758527473
 ,p_command => 
'create table orders ('||wwv_flow.LF||
'    Order_id                       number generated by default on null as identity '||wwv_flow.LF||
'                                   constraint the_order_id_pk primary key,'||wwv_flow.LF||
'    order_date                     date,'||wwv_flow.LF||
'    customer_id                    number,'||wwv_flow.LF||
'    vehicle_id                     number,'||wwv_flow.LF||
'    Order_type_id                  number,'||wwv_flow.LF||
''||wwv_flow.LF||
'    CONSTRAINT FK_customer_id FOREIGN KEY (custo'||
'mer_id) REFERENCES CUSTOMER(CUSTOMER_ID),'||wwv_flow.LF||
'    CONSTRAINT FK_vehicle_id FOREIGN KEY (vehicle_id) REFERENCES VEHICLE(VEHICLE_ID),'||wwv_flow.LF||
'    CONSTRAINT FK_Order_type_id  FOREIGN KEY (Order_type_id) REFERENCES ORDER_TYPE(ORDER_TYPE_ID)'||wwv_flow.LF||
')'||wwv_flow.LF||
';'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110210717','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4539508264031871994
 ,p_command => 
'SELECT * FROM customer;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211347','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4540594811442874424
 ,p_command => 
'INSERT INTO CUSTOMER(CUSTOMER_ID,FIRST_NAME,LAST_NAME,'||wwv_flow.LF||
'    EMAIL_ADDRESS,CONTACT_NUMBER,DATE_OF_BIRTH) VALUES(''Josie'',''Williams'',''rabdu.in.its@gmail.com'',''2102003667'',''18-1-1995'',);'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211354','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4540820581557914884
 ,p_command => 
'INSERT INTO CUSTOMER(CUSTOMER_ID,FIRST_NAME,LAST_NAME,'||wwv_flow.LF||
'    EMAIL_ADDRESS,CONTACT_NUMBER,DATE_OF_BIRTH) VALUES(''Josie'',''Williams'',''rabdu.in.its@gmail.com'',''2102003667'',''18-1-1995'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211355','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4540901327786877340
 ,p_command => 
'INSERT INTO CUSTOMER(FIRST_NAME,LAST_NAME,'||wwv_flow.LF||
'    EMAIL_ADDRESS,CONTACT_NUMBER,DATE_OF_BIRTH) VALUES(''Josie'',''Williams'',''rabdu.in.its@gmail.com'',''2102003667'',''18-1-1995'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211355','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4540905434990878710
 ,p_command => 
'INSERT INTO CUSTOMER(FIRST_NAME,LAST_NAME,'||wwv_flow.LF||
'    EMAIL_ADDRESS,CONTACT_NUMBER,DATE_OF_BIRTH) VALUES(''Josie'',''Williams'',''rabdu.in.its@gmail.com'',''2102003667'',''1-18-1995'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211355','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4541019143068931538
 ,p_command => 
'SELECT * FROM customer;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211357','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4542888409383963106
 ,p_command => 
'INSERT INTO DEPARTMENTS(DEPARTMENT_NAME) '||wwv_flow.LF||
'    VALUES(''Service Technicians'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211403','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4542924082736917801
 ,p_command => 
'INSERT INTO DEPARTMENTS(DEPARTMENT_NAME) '||wwv_flow.LF||
'    VALUES(''Sales Manager'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211402','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4542929969352919411
 ,p_command => 
'INSERT INTO DEPARTMENTS(DEPARTMENT_NAME) '||wwv_flow.LF||
'    VALUES(''Finance Manager'');'||wwv_flow.LF||
''
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211402','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4542940030703921653
 ,p_command => 
'INSERT INTO DEPARTMENTS(DEPARTMENT_NAME) '||wwv_flow.LF||
'    VALUES(''Customer Service Representative'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211402','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4542946023188922138
 ,p_command => 
'SELECT * FROM DEPARTMENTS;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211402','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4543018129169928912
 ,p_command => 
'SELECT * FROM DEPARTMENTS;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211403','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4543280575475952371
 ,p_command => 
'INSERT INTO MANUFACTURE_INFO(MANUFACTURE_NAME,MANUFACTURING_DATE) '||wwv_flow.LF||
'    VALUES(''Porsche'',''2-20-2020'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211407','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4543388697826959769
 ,p_command => 
'INSERT INTO MANUFACTURE_INFO(MANUFACTURE_NAME,MANUFACTURING_DATE) '||wwv_flow.LF||
'    VALUES(''Tesla '',''2-10-2017'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211409','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4543520501601963167
 ,p_command => 
'SELECT * FROM MANUFACTURE_INFO;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211409','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4543733522120001795
 ,p_command => 
'INSERT INTO MANUFACTURE_INFO(MANUFACTURE_NAME,MANUFACTURING_DATE) '||wwv_flow.LF||
'    VALUES(''Toyota'',''7-25-2019'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211409','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4544434899382032162
 ,p_command => 
'INSERT INTO MODEL(MODEL_TITLE,MODEL_YEAR) '||wwv_flow.LF||
'    VALUES(''SUV'',''2-4-2015'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211414','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4544749666061991172
 ,p_command => 
'INSERT INTO MODEL(MODEL_TITLE,MODEL_YEAR) '||wwv_flow.LF||
'    VALUES(''Sedan'',''2-8-2010'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211414','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4544763548067993749
 ,p_command => 
'SELECT * FROM MODEL;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211414','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4545165894623997045
 ,p_command => 
'INSERT INTO MODEL(MODEL_TITLE,MODEL_YEAR) '||wwv_flow.LF||
'    VALUES(''Coupe'',''17-7-2016'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211415','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4545187531485000504
 ,p_command => 
'SELECT * FROM MODEL;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211415','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4548202568658062019
 ,p_command => 
'INSERT INTO SUPPLIERS(SUPPLIERS_ID,SUPPLIERS_NAME,ADDRESS,CONTACT_NUMBER,CITY,COUNTRY) '||wwv_flow.LF||
'    VALUES(''1'',''Asif'',''EC1P 1RP'',''2102027772'',''London'',''UK'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211426','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4548273078512070252
 ,p_command => 
'INSERT INTO SUPPLIERS(SUPPLIERS_ID,SUPPLIERS_NAME,ADDRESS,CONTACT_NUMBER,CITY,COUNTRY) '||wwv_flow.LF||
'    VALUES(''2'',''Dennis'',''CC1P 5OP'',''2102027772'',''London'',''UK'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211427','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4548515494273083584
 ,p_command => 
'INSERT INTO SUPPLIERS(SUPPLIERS_ID,SUPPLIERS_NAME,ADDRESS,CONTACT_NUMBER,CITY,COUNTRY) '||wwv_flow.LF||
'    VALUES(''3'',''Amy G Baldwin'',''N3 8JY'',''1104027796'',''Manchester'',''England'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211429','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4548542523824088385
 ,p_command => 
'SELECT * FROM MODEL;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211430','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4549360897403130114
 ,p_command => 
'SELECT * FROM SUPPLIERS;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211430','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4553014045774172170
 ,p_command => 
'INSERT INTO STAFF_TYPE(STAFF_TYPE_ID,STAFF_TYPE_NAME) '||wwv_flow.LF||
'    VALUES(''1'',''Sales-Man'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211437','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4554612268757142199
 ,p_command => 
'INSERT INTO STAFF_TYPE(STAFF_TYPE_ID,STAFF_TYPE_NAME) '||wwv_flow.LF||
'    VALUES(''2'',''Lot-Manager'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211439','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4555010786943143883
 ,p_command => 
'SELECT * STAFF_TYPE;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211439','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4555029381847145279
 ,p_command => 
'SELECT * FROM STAFF_TYPE;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211439','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4561868479545197071
 ,p_command => 
'INSERT INTO SHOWROOMS(SHOWROOMS_ID,SHOWROOM_NAME,ADDRESS,CONTACT_NUMBER,STATES) '||wwv_flow.LF||
'    VALUES(''2'',''Motor Empire'',''26 Seven Oaks Rd'',''7318476208'',''North Billerica'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211448','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4562528918002206686
 ,p_command => 
'INSERT INTO SHOWROOMS(SHOWROOMS_ID,SHOWROOM_NAME,ADDRESS,CONTACT_NUMBER,STATES) '||wwv_flow.LF||
'    VALUES(''3'',''Bliss Car World'',''Lake Crystal'',''438476209'',''2805 Lakeview Rd'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211450','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4562529734532207040
 ,p_command => 
'SELECT * FROM SHOWROOMS;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211450','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4565435507358274012
 ,p_command => 
'INSERT INTO STAFF(STAFF_ID,FIRST_NAME,LAST_NAME,EMAIL_ADDRESS,CONTACT_NUMBER,DATE_OF_BIRTH,STAFF_TYPE_ID,DEPARTMENT_ID,SHOWROOM_ID) '||wwv_flow.LF||
'    VALUES(''1'',''James'',''Smith'',''kkouma@gmail.com'',''2102272196'',''5-24-1990'',''1'',''1'',''1'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211501','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4565502957936316532
 ,p_command => 
'SELECT * FROM STAFF;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211502','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4567782379425342969
 ,p_command => 
'INSERT INTO STAFF(STAFF_ID,FIRST_NAME,LAST_NAME,EMAIL_ADDRESS,CONTACT_NUMBER,DATE_OF_BIRTH,STAFF_TYPE_ID,DEPARTMENT_ID,SHOWROOM_ID) '||wwv_flow.LF||
'    VALUES(''2'','' Wayne'',''Johnson'',''Johnson@gmail.com'',''9702291146'',''3-20-1997'',''4'',''2'',''2'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211512','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4567841871234385733
 ,p_command => 
'SELECT * FROM STAFF;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211513','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4574787618339488392
 ,p_command => 
'INSERT INTO VEHICLE_TYPE(VEHICLE_TYPE_ID,VEHICLE_TYPE_NAME) '||wwv_flow.LF||
'    VALUES(''5'','' Convertible'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211530','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4575918224668495449
 ,p_command => 
'SELECT * FROM VEHICLE_TYPE;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211531','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4632723383788095395
 ,p_command => 
'alter table "VEHICLE" drop column'||wwv_flow.LF||
'"MAINTENANCE_ID"'||wwv_flow.LF||
'/   '||wwv_flow.LF||
''
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211711','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4632913030571072981
 ,p_command => 
'alter table "VEHICLE_MAINTENANCE_RECORD" add constraint'||wwv_flow.LF||
'"FK_VAHICLE_ID" foreign key ("VEHICLE_ID") references "VEHICLE" ("VEHICLE_ID") on delete cascade'||wwv_flow.LF||
'/   '||wwv_flow.LF||
''
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211714','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4633501148911125030
 ,p_command => 
'select * from VEHICLE_TYPE;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211716','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4633671613533110442
 ,p_command => 
'select * from supplier;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211720','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4633671770585110911
 ,p_command => 
'select * from suppliers;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211720','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4633706757752147072
 ,p_command => 
'select * from Model;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211720','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4633744828487160485
 ,p_command => 
'INSERT INTO VEHICLE(VEHICLE_ID,VEHICLE_NAME,COLOR,PRICE,VEHICLE_TYPE_ID,MODEL_ID,SUPPLIER_ID)     '||wwv_flow.LF||
' VALUES(''1'',''Honda City'',''White'',''30000'',''1'',''1'',''1'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211722','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4633785499845170508
 ,p_command => 
'select * from VEHICLE_TYPE;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211724','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4633795558453173035
 ,p_command => 
'select * from Model;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211724','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4633799329003174151
 ,p_command => 
'select * from suppliers;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211724','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4634130298107180937
 ,p_command => 
'select * from Model;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211726','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4634151566071183634
 ,p_command => 
'INSERT INTO VEHICLE(VEHICLE_ID,VEHICLE_NAME,COLOR,PRICE,VEHICLE_TYPE_ID,MODEL_ID,SUPPLIER_ID)     '||wwv_flow.LF||
' VALUES(''2'',''BMW 5 Series'',''Black'',''68000'',''5'',''2'',''3'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211726','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4634210661763140667
 ,p_command => 
'select * from VEHICLE_TYPE;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211725','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4634216673765143693
 ,p_command => 
'select * from suppliers;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211726','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4634219959638146728
 ,p_command => 
''||wwv_flow.LF||
'INSERT INTO VEHICLE(VEHICLE_ID,VEHICLE_NAME,COLOR,PRICE,VEHICLE_TYPE_ID,MODEL_ID,SUPPLIER_ID)     '||wwv_flow.LF||
' VALUES(''3'',''BMW 5 Series'',''Black'',''68000'',''5'',''2'',''3'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211726','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4634963475203209005
 ,p_command => 
'select * from ORDERS;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211737','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4635989438254220799
 ,p_command => 
'select * from customer;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211739','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4636031189084267965
 ,p_command => 
'select * from customer;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211740','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4636038142443270309
 ,p_command => 
'INSERT INTO ORDERS(ORDER_ID,ORDER_DATE,CUSTOMER_ID,VEHICLE_ID,ORDER_TYPE_ID)     '||wwv_flow.LF||
' VALUES(''2'',''10-8-2021'',''2'',''3'',''2'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211740','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4636131351221224727
 ,p_command => 
'select * from VEHICLE;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211739','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4636142015812226397
 ,p_command => 
'INSERT INTO ORDERS(ORDER_ID,ORDER_DATE,CUSTOMER_ID,VEHICLE_ID,ORDER_TYPE_ID)     '||wwv_flow.LF||
' VALUES(''1'',''10-10-2021'',''1'',''1'',''1'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211740','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4636146329030230129
 ,p_command => 
'select * from VEHICLE;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211740','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4636343915052285608
 ,p_command => 
'select * from staff;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211743','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4636367052578288464
 ,p_command => 
''||wwv_flow.LF||
'select * from VEHICLE;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211743','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4665989869657990120
 ,p_command => 
'Select ORDER_ID,ORDER_DATE,ORDER_DATE,VEHICLE_ID,VEHICLE_ID'||wwv_flow.LF||
'    FROM ORDERS JOIN CUSTOMER ON ORDERS.CUSTOMER_ID = CUSTOMER.CUSTOMER_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211947','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4665992728320994106
 ,p_command => 
'Select ORDER_ID,ORDER_DATE,ORDERS.CUSTOMER_ID,VEHICLE_ID,VEHICLE_ID'||wwv_flow.LF||
'    FROM ORDERS JOIN CUSTOMER ON ORDERS.CUSTOMER_ID = CUSTOMER.CUSTOMER_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211948','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4666038520928005150
 ,p_command => 
'select * from ORDERS;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211943','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4666186525020031622
 ,p_command => 
'Select ORDER_ID,ORDER_DATE,CUSTOMER_ID,VEHICLE_ID,VEHICLE_ID'||wwv_flow.LF||
'    FROM ORDERS JOIN CUSTOMER ON ORDERS.CUSTOMER_ID = CUSTOMER.CUSTOMER_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211947','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4666210129832996281
 ,p_command => 
'Select ORDER_ID,ORDER_DATE,CUSTOMER.CUSTOMER_ID,VEHICLE_ID,VEHICLE_ID'||wwv_flow.LF||
'    FROM ORDERS JOIN CUSTOMER ON ORDERS.CUSTOMER_ID = CUSTOMER.CUSTOMER_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211948','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4667261175233031301
 ,p_command => 
'Select * FORM ORDERS INNER JOIN CUSTOMER ON ORDERS.CUSTOMER_ID = CUSTOMER.CUSTOMER_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211954','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4668395349111074383
 ,p_command => 
'Select * FROM ORDERS INNER JOIN CUSTOMER ON ORDERS.CUSTOMER_ID = CUSTOMER.CUSTOMER_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211954','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4670320194935069969
 ,p_command => 
'Select 0.ORDER_ID, O.ORDER_DATE, C.FIRST_NAME,O.VEHICLE_ID, O.ORDER_TYPE_ID'||wwv_flow.LF||
' FROM ORDERS O INNER JOIN CUSTOMER C ON ORDERS.CUSTOMER_ID = CUSTOMER.CUSTOMER_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212000','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4670327853246072647
 ,p_command => 
'Select O.ORDER_ID, O.ORDER_DATE, C.FIRST_NAME,O.VEHICLE_ID, O.ORDER_TYPE_ID'||wwv_flow.LF||
' FROM ORDERS O INNER JOIN CUSTOMER C ON ORDERS.CUSTOMER_ID = CUSTOMER.CUSTOMER_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212001','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4671028965011113990
 ,p_command => 
'Select O.ORDER_ID, O.ORDER_DATE, C.FIRST_NAME,O.VEHICLE_ID, O.ORDER_TYPE_ID'||wwv_flow.LF||
' FROM ORDERS O INNER JOIN CUSTOMER C ON O.CUSTOMER_ID = C.CUSTOMER_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212001','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4671978859308148478
 ,p_command => 
'select * from ORDERS;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212007','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4673937907995139687
 ,p_command => 
'select * from ORDERS;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212012','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4674001549665181855
 ,p_command => 
'Select O.ORDER_ID, O.ORDER_DATE, C.FIRST_NAME,O.VEHICLE_ID, O.ORDER_TYPE_ID'||wwv_flow.LF||
' FROM ORDERS O '||wwv_flow.LF||
' INNER JOIN CUSTOMER C '||wwv_flow.LF||
' ON O.CUSTOMER_ID = C.CUSTOMER_ID'||wwv_flow.LF||
' INNER JOIN VEHICLE v '||wwv_flow.LF||
' ON O.VEHICLE_ID = v.VEHICLE_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212012','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4674026198877184637
 ,p_command => 
'Select O.ORDER_ID, O.ORDER_DATE, C.FIRST_NAME,v.VEHICLE_ID, O.ORDER_TYPE_ID'||wwv_flow.LF||
' FROM ORDERS O '||wwv_flow.LF||
' INNER JOIN CUSTOMER C '||wwv_flow.LF||
' ON O.CUSTOMER_ID = C.CUSTOMER_ID'||wwv_flow.LF||
' INNER JOIN VEHICLE v '||wwv_flow.LF||
' ON O.VEHICLE_ID = v.VEHICLE_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212013','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4674035187125187479
 ,p_command => 
'Select O.ORDER_ID, O.ORDER_DATE, C.FIRST_NAME,v.VEHICLE_NAME, O.ORDER_TYPE_ID'||wwv_flow.LF||
' FROM ORDERS O '||wwv_flow.LF||
' INNER JOIN CUSTOMER C '||wwv_flow.LF||
' ON O.CUSTOMER_ID = C.CUSTOMER_ID'||wwv_flow.LF||
' INNER JOIN VEHICLE v '||wwv_flow.LF||
' ON O.VEHICLE_ID = v.VEHICLE_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212013','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4674701629653194791
 ,p_command => 
'Select O.ORDER_ID, O.ORDER_DATE, C.FIRST_NAME,v.VEHICLE_NAME, ot.ORDER_TYPE_NAME'||wwv_flow.LF||
' FROM ORDERS O '||wwv_flow.LF||
' INNER JOIN CUSTOMER C '||wwv_flow.LF||
' ON O.CUSTOMER_ID = C.CUSTOMER_ID'||wwv_flow.LF||
' INNER JOIN VEHICLE v '||wwv_flow.LF||
' ON O.VEHICLE_ID = v.VEHICLE_ID'||wwv_flow.LF||
' INNER JOIN ORDER_TYPE ot '||wwv_flow.LF||
' ON O.ORDER_TYPE_ID = ot.ORDER_TYPE_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212015','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4558238879253225464
 ,p_command => 
'INSERT INTO SHOWROOMS(SHOWROOMS_ID,SHOWROOM_NAME,ADDRESS,CONTACT_NUMBER,STATES) '||wwv_flow.LF||
'    VALUES(''1'',''Car Time'',''45 Martin Park,'',''276638098'',''St, Axton, VA'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211446','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4632856032379061674
 ,p_command => 
'alter table "VEHICLE_MAINTENANCE_RECORD" add'||wwv_flow.LF||
'("VEHICLE_ID" NUMBER)'||wwv_flow.LF||
'/   '||wwv_flow.LF||
''
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211712','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4634107035799175081
 ,p_command => 
'INSERT INTO VEHICLE(VEHICLE_ID,VEHICLE_NAME,COLOR,PRICE,VEHICLE_TYPE_ID,MODEL_ID,SUPPLIER_ID)     '||wwv_flow.LF||
' VALUES(''2'',''Audi A6'',''Red'',''50000'',''4'',''2'',''2'');'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211725','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4634224519649148622
 ,p_command => 
'select * from VEHICLE;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110211727','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4671980529038149209
 ,p_command => 
'select * from VEHICLE;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212007','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4677577382297248767
 ,p_command => 
'select * from staff;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212024','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4678382608320238190
 ,p_command => 
' Select S.STAFF_ID, S.FIRST_NAME, S.LAST_NAME,S.EMAIL_ADDRESS, S.CONTACT_NUMBER,S.DATE_OF_BIRTH,ST.STAFF_TYPE_NAME,D.DEPARTMENT_NAME,SW.SHOWROOM_NAME'||wwv_flow.LF||
' FROM STAFF S '||wwv_flow.LF||
' INNER JOIN STAFF_TYPE ST'||wwv_flow.LF||
' ON S.STAFF_TYPE_ID = ST.STAFF_TYPE_ID'||wwv_flow.LF||
' INNER JOIN DEPARTMENTS D'||wwv_flow.LF||
' ON S.DEPARTMENT_ID = D.DEPARTMENTS_ID'||wwv_flow.LF||
' INNER JOIN SHOWROOMS SW'||wwv_flow.LF||
' ON S.SHOWROOM_ID = SW.SHOWROOM_NAME;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212028','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4678717257171244018
 ,p_command => 
' Select S.STAFF_ID, S.FIRST_NAME, S.LAST_NAME,S.EMAIL_ADDRESS, S.CONTACT_NUMBER,S.DATE_OF_BIRTH,ST.STAFF_TYPE_NAME,D.DEPARTMENT_NAME,SW.SHOWROOM_NAME'||wwv_flow.LF||
' FROM STAFF S '||wwv_flow.LF||
' INNER JOIN STAFF_TYPE ST'||wwv_flow.LF||
' ON S.STAFF_TYPE_ID = ST.STAFF_TYPE_ID'||wwv_flow.LF||
' INNER JOIN DEPARTMENTS D'||wwv_flow.LF||
' ON S.DEPARTMENT_ID = D.DEPARTMENTS_ID'||wwv_flow.LF||
' INNER JOIN SHOWROOMS SW'||wwv_flow.LF||
' ON S.SHOWROOM_ID = SW.SHOWROOMS_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212029','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4678822246136285489
 ,p_command => 
'select * from staff;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212030','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4678826667766286567
 ,p_command => 
'Select S.STAFF_ID, S.FIRST_NAME, S.LAST_NAME,S.EMAIL_ADDRESS, S.CONTACT_NUMBER,S.DATE_OF_BIRTH,ST.STAFF_TYPE_NAME,D.DEPARTMENT_NAME,SW.SHOWROOM_NAME'||wwv_flow.LF||
' FROM STAFF S '||wwv_flow.LF||
' INNER JOIN STAFF_TYPE ST'||wwv_flow.LF||
' ON S.STAFF_TYPE_ID = ST.STAFF_TYPE_ID'||wwv_flow.LF||
' INNER JOIN DEPARTMENTS D'||wwv_flow.LF||
' ON S.DEPARTMENT_ID = D.DEPARTMENTS_ID'||wwv_flow.LF||
' INNER JOIN SHOWROOMS SW'||wwv_flow.LF||
' ON S.SHOWROOM_ID = SW.SHOWROOMS_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212030','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4680177787821268980
 ,p_command => 
'select * from VEHICLE;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212033','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4680735678204300304
 ,p_command => 
' Select V.VEHICLE_ID, V.VEHICLE_NAME, V.COLOR,V.PRICE, VT.VEHICLE_TYPE_NAME,M.MODEL_TITLE,S.SUPPLIERS_NAME'||wwv_flow.LF||
' FROM VEHICLE V '||wwv_flow.LF||
' INNER JOIN VEHICLE_TYPE VT'||wwv_flow.LF||
' ON V.VEHICLE_TYPE_ID = VT.VEHICLE_TYPE_ID'||wwv_flow.LF||
' INNER JOIN MODEL M'||wwv_flow.LF||
' ON V.MODEL_ID = M.MODEL_ID'||wwv_flow.LF||
' INNER JOIN SUPPLIERS S'||wwv_flow.LF||
' ON V.SUPPLIER_ID = S.SUPPLIERS_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212039','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4680754187249307843
 ,p_command => 
''||wwv_flow.LF||
'select * from VEHICLE_MAINTENANCE_RECORD;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212040','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4683138876033390445
 ,p_command => 
' Select V.ID, V.SERVICE_DATE, V.CONDITION_DESCR,S.FIRST_NAME, VH.VEHICLE_NAME'||wwv_flow.LF||
' FROM VEHICLE_MAINTENANCE_RECORD V '||wwv_flow.LF||
' INNER JOIN STAFF S'||wwv_flow.LF||
' ON V.STAFF_ID = S.STAFF_ID'||wwv_flow.LF||
' INNER JOIN VEHICLE VH'||wwv_flow.LF||
' ON V.VEHICLE_ID = VH.VEHICLE_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212047','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4684268152435457396
 ,p_command => 
' Select V.ID, V.SERVICE_DATE, V.CONDITION_DESCR,S.FIRST_NAME, VH.VEHICLE_NAME '||wwv_flow.LF||
' FROM VEHICLE_MAINTENANCE_RECORD V '||wwv_flow.LF||
' INNER JOIN STAFF S'||wwv_flow.LF||
' ON V.STAFF_ID = S.STAFF_ID'||wwv_flow.LF||
' INNER JOIN VEHICLE VH'||wwv_flow.LF||
' ON V.VEHICLE_ID = VH.VEHICLE_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212058','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4684272449525458659
 ,p_command => 
''||wwv_flow.LF||
' Select V.ID, V.SERVICE_DATE, V.CONDITION_DESCR,S.FIRST_NAME, VH.VEHICLE_NAME asc,'||wwv_flow.LF||
' FROM VEHICLE_MAINTENANCE_RECORD V '||wwv_flow.LF||
' INNER JOIN STAFF S'||wwv_flow.LF||
' ON V.STAFF_ID = S.STAFF_ID'||wwv_flow.LF||
' INNER JOIN VEHICLE VH'||wwv_flow.LF||
' ON V.VEHICLE_ID = VH.VEHICLE_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212059','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4684313004763415476
 ,p_command => 
' Select V.ID, V.SERVICE_DATE, V.CONDITION_DESCR,S.FIRST_NAME, VH.VEHICLE_NAME asc'||wwv_flow.LF||
' FROM VEHICLE_MAINTENANCE_RECORD V '||wwv_flow.LF||
' INNER JOIN STAFF S'||wwv_flow.LF||
' ON V.STAFF_ID = S.STAFF_ID'||wwv_flow.LF||
' INNER JOIN VEHICLE VH'||wwv_flow.LF||
' ON V.VEHICLE_ID = VH.VEHICLE_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212058','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4684315649587416803
 ,p_command => 
''||wwv_flow.LF||
' Select V.ID, V.SERVICE_DATE, V.CONDITION_DESCR,S.FIRST_NAME, VH.VEHICLE_NAME '||wwv_flow.LF||
' FROM VEHICLE_MAINTENANCE_RECORD V asc'||wwv_flow.LF||
' INNER JOIN STAFF S'||wwv_flow.LF||
' ON V.STAFF_ID = S.STAFF_ID'||wwv_flow.LF||
' INNER JOIN VEHICLE VH'||wwv_flow.LF||
' ON V.VEHICLE_ID = VH.VEHICLE_ID;'||wwv_flow.LF||
''
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212058','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4684348824122417633
 ,p_command => 
' Select V.ID, V.SERVICE_DATE, V.CONDITION_DESCR,S.FIRST_NAME, VH.VEHICLE_NAME '||wwv_flow.LF||
' FROM VEHICLE_MAINTENANCE_RECORD V asc,'||wwv_flow.LF||
' INNER JOIN STAFF S'||wwv_flow.LF||
' ON V.STAFF_ID = S.STAFF_ID'||wwv_flow.LF||
' INNER JOIN VEHICLE VH'||wwv_flow.LF||
' ON V.VEHICLE_ID = VH.VEHICLE_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212058','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4684768753851420508
 ,p_command => 
' Select V.ID, V.SERVICE_DATE, V.CONDITION_DESCR,S.FIRST_NAME, VH.VEHICLE_NAME '||wwv_flow.LF||
' FROM VEHICLE_MAINTENANCE_RECORD V '||wwv_flow.LF||
' INNER JOIN STAFF S'||wwv_flow.LF||
' ON V.STAFF_ID = S.STAFF_ID'||wwv_flow.LF||
' INNER JOIN VEHICLE VH'||wwv_flow.LF||
' ON V.VEHICLE_ID = VH.VEHICLE_ID;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212059','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4685980292258497993
 ,p_command => 
'SELECT * '||wwv_flow.LF||
'   FROM VEHICLE '||wwv_flow.LF||
'   WHERE VEHICLE_ID IN (SELECT ID '||wwv_flow.LF||
'         FROM MODEL '||wwv_flow.LF||
'         WHERE MODEL_YEAR > 2-4-2015) ;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212112','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4685986236023501336
 ,p_command => 
'SELECT * '||wwv_flow.LF||
'   FROM VEHICLE '||wwv_flow.LF||
'   WHERE VEHICLE_ID IN (SELECT VEHICLE_ID '||wwv_flow.LF||
'         FROM MODEL '||wwv_flow.LF||
'         WHERE MODEL_YEAR = 2-4-2015) ;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212112','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4686364994976538377
 ,p_command => 
'SELECT * '||wwv_flow.LF||
'   FROM VEHICLE '||wwv_flow.LF||
'   WHERE VEHICLE_ID IN (SELECT VEHICLE_ID '||wwv_flow.LF||
'         FROM MODEL '||wwv_flow.LF||
'         WHERE MODEL_YEAR > 2-4-2015) ;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212112','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4686376090809542308
 ,p_command => 
'SELECT * '||wwv_flow.LF||
'   FROM VEHICLE '||wwv_flow.LF||
'   WHERE VEHICLE_ID IN (SELECT VEHICLE_ID '||wwv_flow.LF||
'         FROM MODEL '||wwv_flow.LF||
'         WHERE MODEL_YEAR = 12-04-2015) ;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212112','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4686403176953505554
 ,p_command => 
'SELECT * '||wwv_flow.LF||
'   FROM VEHICLE '||wwv_flow.LF||
'   WHERE VEHICLE_ID IN (SELECT VEHICLE_ID '||wwv_flow.LF||
'         FROM MODEL '||wwv_flow.LF||
'         WHERE MODEL_YEAR < 12/04/2015) ;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212113','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4686416886378508017
 ,p_command => 
'SELECT * '||wwv_flow.LF||
'   FROM VEHICLE '||wwv_flow.LF||
'   WHERE VEHICLE_ID IN (SELECT VEHICLE_ID '||wwv_flow.LF||
'         FROM MODEL '||wwv_flow.LF||
'         WHERE MODEL_ID =1 ) ;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212113','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4686708868192550207
 ,p_command => 
'SELECT * '||wwv_flow.LF||
'   FROM VEHICLE '||wwv_flow.LF||
'   WHERE VEHICLE_ID IN (SELECT VEHICLE_ID '||wwv_flow.LF||
'         FROM MODEL '||wwv_flow.LF||
'         WHERE MODEL_ID =2 ) ;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212114','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4686739907860555824
 ,p_command => 
''||wwv_flow.LF||
'SELECT * '||wwv_flow.LF||
'   FROM VEHICLE '||wwv_flow.LF||
'   WHERE PRICE <50000;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212115','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4686743145319556969
 ,p_command => 
'SELECT * '||wwv_flow.LF||
'   FROM VEHICLE '||wwv_flow.LF||
'   WHERE PRICE <=50000;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212115','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4687864671089574522
 ,p_command => 
''||wwv_flow.LF||
'SELECT * '||wwv_flow.LF||
'   FROM STAFF '||wwv_flow.LF||
'   WHERE SHOWROOM_ID('||wwv_flow.LF||
'       SELECT * '||wwv_flow.LF||
'        FROM SHOWROOMS WHERE SHOWROOMS_ID =1;'||wwv_flow.LF||
'   );'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212118','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 4687868596275575308
 ,p_command => 
''||wwv_flow.LF||
'SELECT * '||wwv_flow.LF||
'   FROM STAFF '||wwv_flow.LF||
'   WHERE SHOWROOM_ID('||wwv_flow.LF||
'       SELECT * '||wwv_flow.LF||
'        FROM SHOWROOMS WHERE SHOWROOMS_ID =1'||wwv_flow.LF||
'   );'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110212118','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 5124239168470753492
 ,p_command => 
'SELECT * FROM ORDERS'||wwv_flow.LF||
'ORDER BY ORDER_DATE ASC;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110222008','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 5124361206303814684
 ,p_command => 
'UPDATE STAFF'||wwv_flow.LF||
'SET FIRST_NAME=''Alfred Schmidt'''||wwv_flow.LF||
'WHERE STAFF_ID=1;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110222011','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 5124400192012778563
 ,p_command => 
'select * from STAFF;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110222012','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 5124473121224804156
 ,p_command => 
'DELETE FROM CUSTOMER WHERE CUSTOMER_ID=3;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110222016','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 5124555618308836530
 ,p_command => 
'select * from CUSTOMER;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110222015','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 5124596114447841972
 ,p_command => 
'DELETE FROM CUSTOMER WHERE condition CUSTOMER_ID=3;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110222016','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 5124777066182804613
 ,p_command => 
'select * from CUSTOMER;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110222016','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
begin
  wwv_flow_api.create_sw_sql_cmds (
    p_id => 5124164587631791290
 ,p_command => 
'SELECT * FROM ORDERS'||wwv_flow.LF||
'ORDER BY ORDER_DATE DESC;'
    ,p_created_by => '1001071@DAFFODIL.AC'
    ,p_created_on => to_date('202110222007','YYYYMMDDHH24MI')
    ,p_parsed_schema => 'WKSP_DDDRYANGOMES');
end;
/
----------------
--Quick SQL saved models
--
----------------
--user access log
--
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110201350','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.2',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110210619','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.4',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110211209','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.2',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110211212','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.4',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110211331','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.4',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110211347','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.2',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110211356','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.2',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110211357','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.2',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110211405','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.2',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110211407','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.2',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110211410','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.4',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110221437','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.4',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110222004','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.2',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110222004','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.2',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110222004','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.4',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110222006','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.4',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110222007','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.4',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110222007','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.4',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110222009','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.4',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
begin
  wwv_flow_api.create_user_access_log1$ (
    p_login_name => '1001071@DAFFODIL.AC',
    p_auth_method => 'Internal Authentication',
    p_app => 4500,
    p_owner => 'APEX_210200',
    p_access_date => to_date('202110250645','YYYYMMDDHH24MI'),
    p_ip_address => '100.114.32.2',
    p_remote_user => 'APEX_PUBLIC_USER',
    p_auth_result => 0,
    p_custom_status_text => '');
end;
/
prompt Check Compatibility...
begin
-- This date identifies the minimum version required to import this file.
wwv_flow_team_api.check_version(p_version_yyyy_mm_dd=>'2010.05.13');
end;
/
 
begin wwv_flow.g_import_in_progress := true; wwv_flow.g_user := USER; end; 
/
 
--
prompt ...feedback
--
begin
null;
end;
/
--
prompt ...Issue Templates
--
begin
null;
end;
/
--
prompt ...Issue Email Prefs
--
begin
null;
end;
/
--
prompt ...Label Groups
--
begin
null;
end;
/
--
prompt ...Labels
--
begin
null;
end;
/
--
prompt ... Milestones
--
begin
null;
end;
/
--
prompt ... Issues
--
begin
null;
end;
/
--
prompt ... Issue Attachments
--
begin
null;
end;
/
--
prompt ... Issues Milestones
--
begin
null;
end;
/
--
prompt ... Issues Labels
--
begin
null;
end;
/
--
prompt ... Issues stakeholders
--
begin
null;
end;
/
--
prompt ... Issues Comments
--
begin
null;
end;
/
--
prompt ... Issues Events
--
begin
null;
end;
/
--
prompt ... Issues Notifications
--
begin
null;
end;
/
 
prompt ...workspace objects
 
 
prompt ...RESTful Services
 
-- SET SCHEMA
 
begin
 
   wwv_flow_api.g_id_offset := 0;
   wwv_flow_hint.g_schema   := 'WKSP_DDDRYANGOMES';
   wwv_flow_hint.check_schema_privs;
 
end;
/

 
--------------------------------------------------------------------
prompt  SCHEMA WKSP_DDDRYANGOMES - User Interface Defaults, Table Defaults

--------------------------------------------------------------------
 
begin
 
   wwv_flow_api.g_id_offset := 0;
   wwv_flow_hint.g_exp_workspace := 'DDD_RYANGOMES';
 
end;
/

begin
wwv_flow_api.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false));
commit;
end;
/
set verify on feedback on define on
prompt  ...done
